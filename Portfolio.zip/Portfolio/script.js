function edu(){
    document.getElementById('change-text-1').innerHTML="B.Tech In CSE ,Lucknow UP";
    document.getElementById('change-text-2').innerHTML="12th  In 2019 ,Gonda UP";
    document.getElementById('change-text-3').innerHTML="10th  In 2017 ,Gonda UP";
    return true;
    }
    function skill(){

        document.getElementById('change-text-1').innerHTML="FrontEnd Developer";
        document.getElementById('change-text-2').innerHTML="BackEnd Developer";
        document.getElementById('change-text-3').innerHTML="FullStack Developer";

    }

